﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hotSpot : MonoBehaviour
{
    public static List<Vector4> HS_Vector_list = new List<Vector4>();   //vector4 前存座標 最後一個存count
    public static float Radius=1.0f;
    public static float MaxCount=0.0f;

    public static float MaxElement_x = 1.0f;
    public static float MinElement_x = 0.0f;

    public static float MaxElement_y = 1.0f;
    public static float MinElement_y = 0.0f;

    public static float MaxElement_z = 1.0f;
    public static float MinElement_z = 0.0f;

    public static float MaxElement_w = 1.0f;
    public static float MinElement_w = 0.0f;

}
