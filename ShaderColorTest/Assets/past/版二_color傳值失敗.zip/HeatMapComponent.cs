﻿using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class HeatMapComponent : MonoBehaviour
{
    #region 變數們
    private Material m_material = null;
    public Material material
    {
        get
        {
            if (null == m_material)
            {
                Renderer render = this.GetComponent<Renderer>();
                if (null == render)
                    Debug.LogError("Can not found Renderer component on HeatMapComponent");
                m_material = render.material;
            }
            return m_material;
        }
    }
    
    private float influenceRadius = 5.0f;   // 热力影响半径
    #endregion

    private void Start()
    {
        hotSpot.Radius = influenceRadius;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))    //開始畫畫
        {
            shader_dynamic_array();
        }
    }
    public static Vector4[] elements;

    /****************************************************************************************************************************/
    //傳動態長度的資料，由於HLSL無法動態產生array大小。所以透過傳圖片的方式，將資料存在顏色內，已達成目的。
    //可因為color參數介於0~1，所以這裡之前需記錄最大值和最小值，以便壓縮資料。
    //缺點是範圍太大的話，資料壓縮太多，可能失真。所以可能最後有需要固定說每XXX距離就壓縮成一張圖
    public void shader_dynamic_array()
    {
        elements = hotSpot.HS_Vector_list.ToArray();
        int count = elements.Length;
        Texture2D input = new Texture2D(count, 1, TextureFormat.RGBA32, false);
        input.filterMode = FilterMode.Point;
        input.wrapMode = TextureWrapMode.Clamp;

        float elementsRangeX = hotSpot.MaxElement_x - hotSpot.MinElement_x;
        float elementsRangeY = hotSpot.MaxElement_y - hotSpot.MinElement_y;
        float elementsRangeZ = hotSpot.MaxElement_z - hotSpot.MinElement_z;
        float elementsRangeW = hotSpot.MaxElement_w - hotSpot.MinElement_w;

        for (int i = 0; i < count; i++)
        {
            float colorX = (elements[i].x - hotSpot.MinElement_x) / elementsRangeX;
            float colorY = (elements[i].y - hotSpot.MinElement_y) / elementsRangeY;
            float colorZ = (elements[i].z - hotSpot.MinElement_z) / elementsRangeZ;
            float colorW = (elements[i].w - hotSpot.MinElement_w) / elementsRangeW;

            input.SetPixel(i, 0, new Color(colorX, colorY, colorZ, colorW));

            Debug.Log("(elements.x, elements.y, elements.z, elements.w)" + (elements[i].x, elements[i].y, elements[i].z, elements[i].w)
                        + "\n(MinElement_x, MinElement_y, MinElement_z, MinElement_w)" + (hotSpot.MinElement_x, hotSpot.MinElement_y, hotSpot.MinElement_z, hotSpot.MinElement_w)
                        + "\n(elementsRangeX, elementsRangeY, elementsRangeZ, elementsRangeW)" + (elementsRangeX, elementsRangeY, elementsRangeZ, elementsRangeW)
                        + "\n(colorX, colorY, colorZ, colorW)" + (colorX, colorY, colorZ, colorW));
        }
        input.Apply();

        ////////////////////////////////////////////////////////////////////
        byte[] bytes = input.EncodeToPNG();
        var dirPath = Application.dataPath + "/SaveImages/";
        if (!Directory.Exists(dirPath))
        {
            Directory.CreateDirectory(dirPath);
        }
        File.WriteAllBytes(dirPath + "Image" + ".png", bytes);
        ////////////////////////////////////////////////////////////////////

        material.SetTexture("array", input);
        material.SetInt("count", count);

        material.SetFloat("_MinX", hotSpot.MinElement_x);
        material.SetFloat("_RangeX", elementsRangeX);

        material.SetFloat("_MinY", hotSpot.MinElement_y);
        material.SetFloat("_RangeY", elementsRangeY);

        material.SetFloat("_MinZ", hotSpot.MinElement_z);
        material.SetFloat("_RangeZ", elementsRangeZ);

        material.SetFloat("_MinW", hotSpot.MinElement_w);
        material.SetFloat("_RangeW", elementsRangeW);

        material.SetFloat("_Radius", hotSpot.Radius);
        material.SetFloat("_MaxCount", hotSpot.MaxCount);

        /*Debug.Log("_RangeX >> " + elementsRangeX);
        Debug.Log("_RangeY >> " + elementsRangeY);
        Debug.Log("_RangeZ >> " + elementsRangeZ);
        Debug.Log("_RangeW >> " + elementsRangeW);*/
    }
}