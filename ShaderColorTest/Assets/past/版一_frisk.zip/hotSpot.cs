﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hotSpot : MonoBehaviour
{
    public static Vector4 HS1 = new Vector4(0f, 0f, 0f, 0f);
    public static Vector4 HS2 = new Vector4(0f, 0f, 0f, 0f);
    public static Vector4 HS3 = new Vector4(0f, 0f, 0f, 0f);
    public static Vector4 HS4 = new Vector4(0f, 0f, 0f, 0f);
    public static Vector4 HS5 = new Vector4(0f, 0f, 0f, 0f);
    public static Vector4 HS6 = new Vector4(0f, 0f, 0f, 0f);
    public static Vector4 HS7 = new Vector4(0f, 0f, 0f, 0f);
    public static int number = 7;
    public List<Vector4> HSlist = new List<Vector4>();
}
