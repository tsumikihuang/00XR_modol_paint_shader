﻿using UnityEngine;
using System.Collections.Generic;

public enum HeatMapMode
{
    RefreshEachFrame,
    RefreshByInterval
}

public class HeatMapComponent : MonoBehaviour
{
    private Material m_material = null;

    public Material material
    {
        get
        {
            if (null == m_material)
            {
                Renderer render = this.GetComponent<Renderer>();
                if (null == render)
                    Debug.LogError("Can not found Renderer component on HeatMapComponent");
                m_material = render.material;
            }
            return m_material;
        }
    }

    public HeatMapMode heatMapMode = HeatMapMode.RefreshEachFrame;

    // 热力图刷新间隔 TODO: 支持设置为每帧刷新
    public float interval = 0.02f;

    // 热力影响半径
    public float influenceRadius = 1.0f;

    // 亮度
    public float intensity = 3.0f;

    private float m_timer = 0.0f;

    public List<GameObject> impactFactors = new List<GameObject>();



    private void Update()
    {
        if (heatMapMode == HeatMapMode.RefreshEachFrame)
        {
            RefreshHeatmap();
            return;
        }

        m_timer += Time.deltaTime;
        if (m_timer > interval)
        {
            RefreshHeatmap();
            m_timer = 0.0f;
        }
    }

    private void RefreshHeatmap()
    {
        material.SetInt("_FactorCount", hotSpot.number);


        var ifPosition = new Vector4[hotSpot.number];
        ifPosition[0] = hotSpot.HS1;
        ifPosition[1] = hotSpot.HS2;
        ifPosition[2] = hotSpot.HS3;

        ifPosition[3] = hotSpot.HS4;
        ifPosition[4] = hotSpot.HS5;
        ifPosition[5] = hotSpot.HS6;
        ifPosition[6] = hotSpot.HS7;

        material.SetVectorArray("_Factors", ifPosition);

        Vector4[] properties = new Vector4[hotSpot.number];   //7個 裡面存 Vector2[] = [(半徑,亮度)...]
        for (int i = 0; i < hotSpot.number; i++)
            properties[i] = new Vector2(influenceRadius, intensity);
        material.SetVectorArray("_FactorsProperties", properties);
    }
}