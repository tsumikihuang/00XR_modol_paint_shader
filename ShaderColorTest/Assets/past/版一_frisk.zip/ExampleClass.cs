﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleClass : MonoBehaviour
{
    public List<gazePoint> tempStructureList = new List<gazePoint>();

    public struct gazePoint
    {
        public Vector3 point;
        public int count;
    }

    Camera cam;
    bool isWaiting;

    void Start()
    {
        cam = GetComponent<Camera>();
    }

    private float m_timer = 0.0f;
    // 热力图刷新间隔 TODO: 支持设置为每帧刷新
    public float interval = 0.5f;


    void Update()
    {
        RaycastHit hit;
        if (!Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out hit))
            return;

        MeshCollider meshCollider = hit.collider as MeshCollider;
        if (meshCollider == null || meshCollider.sharedMesh == null)
            return;

        //抓取該目標物的點數和三角面數
        Mesh mesh = meshCollider.sharedMesh;
        Vector3[] vertices = mesh.vertices;
        int[] triangles = mesh.triangles;
        Vector3 p0 = vertices[triangles[hit.triangleIndex * 3 + 0]];
        Vector3 p1 = vertices[triangles[hit.triangleIndex * 3 + 1]];
        Vector3 p2 = vertices[triangles[hit.triangleIndex * 3 + 2]];
        
        Transform hitTransform = hit.collider.transform;

        //抓取raycast點到位置的三角形上三個點
        p0 = hitTransform.TransformPoint(p0);       //從 hitTransform 的 local space TO world space
        p1 = hitTransform.TransformPoint(p1);
        p2 = hitTransform.TransformPoint(p2);

        gazePoint point0 = new gazePoint();
        gazePoint point1 = new gazePoint();
        gazePoint point2 = new gazePoint();

        point0.point = p0;
        point1.point = p1;
        point2.point = p2;

        ///////////////**************************************************************************************************************//////////////////

        // List<T> . FindIndex(List<T> value)
        //找到tempStructureList內p0這點的儲存index
        int imatch = tempStructureList.FindIndex(x => x.point == p0);

        //如果沒有的話，就從0開始
        //有的話，原本的值+1
        if (imatch != -1){
            int newCount = tempStructureList[imatch].count + 1;
            tempStructureList.RemoveAt(imatch);     //將舊資料刪除
            point0.count = newCount;
        }else
            point0.count = 0;

        ///////////////**************************************************************************************************************//////////////////

        //同上
        imatch = tempStructureList.FindIndex(x => x.point == p1);
        if (imatch != -1)
        {
            int newCount = tempStructureList[imatch].count + 1;
            tempStructureList.RemoveAt(imatch);
            point1.count = newCount;
        }else
            point1.count = 0;

        //同上
        imatch = tempStructureList.FindIndex(t => t.point == p2);
        if (imatch != -1)
        {
            int newCount = tempStructureList[imatch].count + 1;
            tempStructureList.RemoveAt(imatch);
            point2.count = newCount;
        }else
            point2.count = 0;
        
        //前面刪了 所以現在再加回去
        tempStructureList.Add(point0);
        tempStructureList.Add(point1);
        tempStructureList.Add(point2);

        //如果按了空白建材重畫
        if (Input.GetKeyDown("space"))
        {
            isWaiting = true;
            TestFunc();
        }

        if (isWaiting){
            TestFunc();
        }

        m_timer += Time.deltaTime;
        if (m_timer > interval)
        {
            TestFunc();
            m_timer = 0.0f;
        }
    }

    void TestFunc()
    {
        //排序時左右兩個變量必須是左-比較-右(被比較)，切記不可反過來用。
        //微軟官方推薦的參數命名方式是x(左),y(右)
        //以下可解讀成=>左的count和右的count比較並排序
        tempStructureList.Sort((x,y)=> x.count.CompareTo(y.count)); //小到大排，升序

        //找tempStructureList放在最後的最後三個點
        hotSpot.HS1 = tempStructureList[tempStructureList.Count - 1].point;
        hotSpot.HS2 = tempStructureList[tempStructureList.Count - 2].point;
        hotSpot.HS3 = tempStructureList[tempStructureList.Count - 3].point;

        if (tempStructureList.Count >= 7) {                         //如果大於7才會被畫出來
            hotSpot.HS4 = tempStructureList[tempStructureList.Count - 4].point;
            hotSpot.HS5 = tempStructureList[tempStructureList.Count - 5].point;
            hotSpot.HS6 = tempStructureList[tempStructureList.Count - 6].point;
            hotSpot.HS7 = tempStructureList[tempStructureList.Count - 7].point;
        }

        isWaiting = false;
    }
}
