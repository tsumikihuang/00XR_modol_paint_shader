﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hotSpot : MonoBehaviour
{
    public static Vector4[] HS_Vector_list;     //vector4 前存座標 最後一個存count，每四個資料做為一個點的資料
    public static float Radius=5.0f;
    public static float MaxCount=0.0f;

}
