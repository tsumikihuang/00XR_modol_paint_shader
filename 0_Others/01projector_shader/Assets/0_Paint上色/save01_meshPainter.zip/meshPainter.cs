﻿//掛在模型上
using UnityEngine;
using System.Collections;

[ExecuteInEditMode]                         //讓 Unity 在編輯模式中，可以執行該腳本
[RequireComponent(typeof(MeshCollider))]    //將組件自动被添加到gameobject

public class meshPainter : MonoBehaviour
{

    void Start()
    {
    }
    void Update()
    {
    }
}
